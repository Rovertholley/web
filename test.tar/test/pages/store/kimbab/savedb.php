<?php session_start()?>
<?php 
    if(isset($_POST['submit'])){ 
        foreach($_POST['quantity'] as $key => $val) { 
            if($val==0) { 
                unset($_SESSION['cart'][$key]); 
            }else{ 
                $_SESSION['cart'][$key]['quantity']=$val; 
            } 
        } 
    }
?> 

<?php
$loc = explode(" ", $_POST['location']);
require("connections.php"); 
$sql="SELECT * FROM products WHERE id_product IN ("; 

        foreach($_SESSION['cart'] as $id => $value) { 
            $sql.=$id.","; 
        } 
          
        $sql=substr($sql, 0, -1).") ORDER BY name ASC"; 
        $query=mysql_query($sql); 
		$ordercontent = "";
        while($row=mysql_fetch_array($query)){ 
    ?> 
        <?php $ordercontent=$ordercontent.$row['name']."x".$_SESSION['cart'][$row['id_product']]['quantity']."\n" ?>
        <?php 
              
        } 
    ?> 
<?php
echo $_SESSION['user_name'];
echo "님의 주문현황입니다.<br/>\n";
echo "매장명 : ";
echo $_SESSION['store_name'];
echo "<br/>\n";
echo "주문메뉴 : "."$ordercontent<br/>\n";
echo "주문주소(좌표): "."$loc[0]"." ,"."$loc[1]<br/>\n";

$sql ="INSERT INTO `tutorials`.`order`
(`order_id`, `store_index`, `user_index`, `order_content`, `delivery_lat`, `delivery_long`)
 VALUES (NULL, '31', '22','$ordercontent','$loc[0]','$loc[1]')";
  
  mysql_query($sql);
  
  $select_sql = "SELECT MAX(order_id) from `order`";
  $result = mysql_query($select_sql);
  $server_root_path = $_SERVER['DOCUMENT_ROOT'];
  $detail = "/test/waypoint/";
  while($row=mysql_fetch_array($result))
  {
	$file_num = $row['MAX(order_id)'];
  }
$file_output=$server_root_path.$detail.$file_num.".waypoints";
echo $file_output;

$file = fopen($file_output,"x");


if(!$file) die("adf");

fwrite($file,"QGC WPL 110\n
0\t1\t0\t16\t0\t0\t0\t0\t35.830895\t128.752341\t55.162042\t1\n");
fwrite($file,"1\t0\t3\t22\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t20.000000\t1\n");
fwrite($file,"2\t0\t3\t16\t3.00000000\t0.00000000\t0.00000000\t0.00000000\t");
fwrite($file,$loc[0]);
fwrite($file,"\t");
fwrite($file,$loc[1]);
fwrite($file,"\t");
fwrite($file,"25.000000");
fwrite($file,"\t1\n");
fwrite($file,"3\t0\t3\t21\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.000000\t1\n");
fwrite($file,"4\t0\t3\t93\t10.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.000000\t1\n");
fwrite($file,"5\t0\t3\t22\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t20.000000\t1\n");
fwrite($file,"6\t0\t3\t21\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.000000\t1\n");
?>


