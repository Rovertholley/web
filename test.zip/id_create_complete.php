<html>
<meta charset="UTF-8"/>
<head>

<head>
<body>
<?php
mysql_connect("localhost","root","apmsetup") or die(mysql_error());
mysql_select_db("account"); 
mysql_query("SET NAMES utf8");
$ID = $_POST["id"];      
$NEWPASS = $_POST["newpass"];    
$RENEWPASS = $_POST["renewpass"];
$NAME = $_POST["name"];
$BIRTH = $_POST["birth"];
$GENDER = $_POST["gender"];
$ADDRESS = $_POST["address"];
$PHONE = $_POST["phone"];

$sql = "insert into users (user_id, user_password, user_name, user_birth, gender, user_address, user_phone) values ('$ID', '$NEWPASS','$NAME', '$BIRTH', '$GENDER', '$ADDRESS', '$PHONE')";
mysql_query($sql) or die (mysql_error());
?>
Complete Create!!
<form method='post'>
<input type=button value="메인화면으로" style="height:50px" onClick="location.href='index.html'">
</body>
</html>

<?php
mysql_connect("localhost","root","apmsetup")or die(mysql_error());
mysql_select_db("account");

$sql="SELECT * FROM users";
#$sql="SELECT * FROM Driver";
$result=mysql_query($sql) or die(mysql_error());

echo "
<html>
<body>
<table width='100' border='1'>
<tr>
<h2> Apply List </h2>
<td align='center'>id</td>
<td align='center'>newpasswd</td>
<td align='center'>name</td>
<td align='center'>birth</td>
<td align='center'>gender</td>
<td align='center'>address</td>
<td align='center'>phone</td>
</tr>
";
while($row=mysql_fetch_array($result))
{
echo("
<tr>
<td align='center'>$row[user_id]</td>
<td align='center'>$row[user_password]</td>
<td align='center'>$row[user_name]</td>
<td align='center'>$row[user_birth]</td>
<td align='center'>$row[gender]</td>
<td align='center'>$row[user_address]</td>
<td align='center'>$row[user_phone]</td>
</tr>
");
}
?>
