<?php 
    if(isset($_POST['submit'])){ 
        foreach($_POST['quantity'] as $key => $val) { 
            if($val==0) { 
                unset($_SESSION['cart'][$key]); 
            }else{ 
                $_SESSION['cart'][$key]['quantity']=$val; 
            } 
        } 
    }
?> 

<h1>View cart</h1> 
<a href="index.php?page=products">Go back to the products page.</a> 
<div class="wrapper row4">
  <section id="cta" class="clear">
    <!-- ################################################################################################ -->
    <div class="three_quarter first">
<script>
function getLocation() {
  if (navigator.geolocation) { // GPS를 지원하면
    navigator.geolocation.getCurrentPosition(function(position) {
	  var arr = document.getElementById("location");
	  var loc = position.coords.latitude + ' ' + position.coords.longitude;
	  arr.value = loc;
    }, function(error) {
      console.error(error);
    }, {
      enableHighAccuracy: false,
      maximumAge: 0,
      timeout: Infinity
    });
  } else {
    alert('GPS를 지원하지 않습니다');
  }
}
getLocation();
</script>
      <p id="demo4">아래 버튼을 누르면 현재 위치를 검색합니다.</p>
<!-- ################################################################################################ -->
  </section>
</div>
<form method="post" action="index.php?page=savedb" name = "mainform"> 
      <h2 class="heading">To remove an item set its quantity to 0.</h2>
      <p>위치!</p>
      <input type="text" id="location" name="location" value = "0">
      <input type="button" onclick="getLocation()" value ="위치 검색">
    <table> 
        <tr>
            <th>Name</th> 
            <th>Quantity</th> 
            <th>Price</th> 
            <th>Items Price</th> 
        </tr> 
          
        <?php 
          
            $sql="SELECT * FROM products WHERE id_product IN ("; 
                      
                    foreach($_SESSION['cart'] as $id => $value) { 
                        $sql.=$id.","; 
                    } 
                     
                    $sql=substr($sql, 0, -1).") ORDER BY name ASC"; 
                    $query=mysql_query($sql); 
                    $totalprice=0; 
                    while($row=mysql_fetch_array($query)){ 
                        $subtotal=$_SESSION['cart'][$row['id_product']]['quantity']*$row['price']; 
                        $totalprice+=$subtotal; 
                    ?> 
                        <tr> 
                            <td><?php echo $row['name'] ?></td>
                            <td><input type="text" name="quantity[<?php echo $row['id_product'] ?>]" size="5" value="<?php echo $_SESSION['cart'][$row['id_product']]['quantity'] ?>" /></td>
                            <td><?php echo $row['price'] ?>$</td>
                            <td><?php echo $_SESSION['cart'][$row['id_product']]['quantity']*$row['price'] ?>$</td>
                        </tr> 
                    <?php      
                    }
					?> 
                    <tr> 
                        <td colspan="4">Total Price: <?php echo $totalprice ?></td>
                    </tr> 
    </table> 
    <br/>
    <button type="submit" name="submit"> 주문 </button>
</form> 
<br/> 
