<?php
$server_root_path = $_SERVER['DOCUMENT_ROOT'];
$detail = "/test/waypoint/";
$file = 
$file_output=$server_root_path.$name;
echo $file_output;

$file = fopen($file_output,"x");


if(!$file) die("adf");

fwrite($file,"QGC WPL 110\n
0\t1\t0\t16\t0\t0\t0\t0\t35.830895\t128.752341\t55.162042\t1");

fwrite($file,"1\t0\t3\t22\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t20.000000\t1\n");
fwrite($file,"2\t0\t3\t16\t3.00000000\t0.00000000\t0.00000000\t0.00000000\t");
fwrite($file,_$SESSION['delivery_lat']);
fwrite($file,"\t");
fwrite($file,_$SESSION['delivery_long']);
fwrite($file,"\t");
fwrite($file,"25.000000");
fwrite($file,"\t1\n");
fwrite($file,"3\t0\t3\t21\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.00000000\t0.000000\t1\n");
?>