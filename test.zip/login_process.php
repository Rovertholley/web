<meta charset="utf-8"> 
<?php
session_start();
require("connections.php"); 

$sql="SELECT * FROM users where user_id = '";
$sql.=$_POST['id']."';";
echo "$sql";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
	if($row['user_pass']==$_POST['password'])
	{
		echo "<script> alert('정상 로그인');";	
		echo "window.location.replace('/test/index.html');</script>";
		$_SESSION['user_id'] = $_POST['id'];
		$_SESSION['user_name'] = $row['user_name'];
		$_SESSION['user_index'] = $row['user_index'];
		$_SESSION['flag']="success";
	}
	else
	{
		echo "<script>window.location.replace('/test/login.html');</script>";
		$_SESSION['flag'] = "fail";
	}
}	
?>
</meta>
